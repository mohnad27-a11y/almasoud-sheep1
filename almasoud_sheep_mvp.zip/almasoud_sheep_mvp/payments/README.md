# تكامل الدفع الإلكتروني

التطبيق يجهز خيارات: مدى، Visa، Mastercard، American Express، Apple Pay، Samsung Pay، Tabby، Tamara، بالإضافة إلى كاش وشبكة عند الاستلام.

للتفعيل الإنتاجي يلزم حساب تاجر معتمد، مفاتيح API وWebhooks، واختبار Sandbox لكل مزود. لا تحفظ بيانات البطاقات داخل التطبيق.
